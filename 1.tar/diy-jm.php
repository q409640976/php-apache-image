<?php
	include_once( 'heard.php' );
        include_once( 'heard2.php' );
?>
<!--右边栏-->
	
<?php
	//include_once( 'adsense.php' );
?>					
<h2>软件定做</h2>

<p>你可以搭建到自己的服务器，放到自己服务器更安全。</p>	


		<!--/右边栏-->
<?php
	include_once( 'foot.php' );
?>