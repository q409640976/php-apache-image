<?php
	include_once( 'heard.php' );
        include_once( 'heard2.php' );
	include_once( 'shujuku.php' );
	include_once( 'des.class.php' );
if(!isset($_SESSION['id'])){
  header("Location:login-jm.php");
	exit();
}//发送日记
?>

<?php
	if(isset($_SESSION['moshi']))
	{
	if($_SESSION['moshi']!=2)
 		echo "<h2>仅发布模式登陆</h2><br>";
 	else
 		echo "<h2>发布+查看模式登陆</h2><br>";
	}
	else
	echo "<h2>仅发布模式登陆</h2><br>";
if(isset($_SESSION['key'])){//进入模式设置了，则进入显示
	$sendrst="";
	if(isset($_POST['content']))
	{
    	$_POST['id']=$_SESSION['id'];//用户id
		echo "27 :_POST[id] ".$_POST['id'];
    	$_POST['jiemi']=$_SESSION['key'];//解密的md5码
    	$_POST['sid'] = get_time("string");//日记的sid
    	if(strlen($_POST['content'])<4)
    		$sendrst="请输入日记内容";
    	else {
    	$_POST['content']=en($_POST['content'],$_SESSION['key']);//日记内容（des加密后的）
		echo "34 :_POST[content] ".$_POST['content']." _POST[jiemi] ".$_POST['jiemi']." _POST[sid] ".$_POST['sid'];
    	if(add_blog_by_id($_POST)){
			echo "36 :";
    	update_user_by_id($_SESSION['id'],"udate",get_time(""));
		echo "38 :";
    		$sendrst="发送成功";}
    	else
    		$sendrst= "存储失败";
    		}
	}
//页码控制开始
	$page = 1;
	if(isset($_GET['page']) And $_GET['page'] > 0)
	$page = $_GET['page'];
	$per_page = 10;//每页数量
		$lists = get_blogs($_SESSION['id'],1,8000);
		//echo "sssslists:".count($lists);
	$zongshu = sizeof($lists);
	echo "52 :zongshu".$zongshu;
//定义类
	if(isset($_GET['tag']))
        $_SESSION['lei']=$_GET['tag'];
    else
        $_SESSION['lei']='';
  				//如果不是读写模式，则不显示列表
  				//echo "moshi:".$_SESSION['moshi'];
	if($_SESSION['moshi']!=2)
		$list = null;
	else
	    $list = get_blogs($_SESSION['id'],$page,$per_page,$_SESSION['lei']);//获得日记列表
	echo "64 :sizeof(lists)".sizeof($lists); 
	//分析翻页控件
	$page1 = $page-1;
	$page2 = $page+1;
	$shangyiye = "";
	$xiayiye = "";
	echo "70 :".$xiayiye;
	$shengyu = $zongshu - $page*$per_page;
	if($page1>0)
		$shangyiye = '<a href="/list-jm1.php?page='.$page1.'"><button data-role="button" data-inline="true" data-theme="d">上一页 </button></a>';	
	if($shengyu>0)
		$xiayiye = '<a href="/list-jm1.php?page='.$page2.'"><button data-role="button" data-inline="true" data-theme="d"> 下一页</button></a>';
			//页码控制结束
	//echo $shangyiye.'  '.$xiayiye.'<br><FONT COLOR="red">'.$sendrst.'</FONT>';	//显示下一页 上一页
?>
			<form action="list-jm1.php" method="POST">	
    			<textarea name= "content" id= "content" rows= "3"></textarea>
        <div class="ui-body ui-body-b">
					<fieldset class="ui-grid-a">
							<div class="ui-block-a">
								<input type="text" name="lei" id="lei" placeholder="标签" />
   						</div>
							<div class="ui-block-b">
								<button type="submit" data-theme="a">发送日记</button>
							</div>
	    		</fieldset>
				</div>              
			</form>			

			<form action="list-jm1.php" method="get">	
    			<div class="ui-body ui-body-b">
						<fieldset class="ui-grid-a">
							<div class="ui-block-a">
								<input type="text" name="tag" id="tag" value=""  />
   						</div>
							<div class="ui-block-b">
								<button type="submit" data-theme="b">搜索标签</button>
							</div>
	    			</fieldset>
				</div>              
			</form>	
			<ul data-role="listview"  
				data-filter="true" data-filter-placeholder="搜索本页" 
				data-filter-theme="c">
			<?php
			echo "109 bbbbbbblist:".count($list);
      if(count($list)>0)
 
			foreach ($list as $v){
				if(strlen($v['content'])>0)
				echo '<li >
				<h3>'.$v['cdate'].'</h3>
				<p class="ui-li-desc1">'.de($v['content'],$_SESSION['key']).'</p>			
<p class="ui-li-aside">标签：<strong>'.$v['lei'].'</strong></p>
			</li>';
				}
			?>	
			</ul>
			<?php
				echo $shangyiye.'  '.$xiayiye;	//显示下一页 上一页
			}
			else{//没输入key的情况
				if(isset($_POST['key'])){
				$user = get_user_by_id($_SESSION['id']);
				if($user['jiemi'] != md5($_POST['key']))
					echo '<FONT COLOR="red">加密密匙验证失败，如忘记，请放弃此号。</FONT>';
				else
				{
					$_SESSION['key'] = $_POST['key'];
					$_SESSION['moshi'] = $_POST['moshi'];
					header("Location:list-jm1.php");
				}
				}
				echo '
    	<div class="text-left">
            <form  action="list-jm1.php" method="post">
                <div class="form-group">
                    <label for="name">加密密匙</label>
                    <input type="password" class="form-control" name="key" id="key" value=""  />
                </div>
                <div class="form-group">
                    <label for="phone">登录模式</label>
                    <select name="moshi" id="moshi">
						<option value="2">查看+发布</option>
                        <option value="1">仅发布</option>
   					</select>
                </div>
                <button type="submit" class="btn btn-success">进入</button>
            </form>
        </div>	';
			}
			
			?>
		<!--/右边栏-->
<?php
	include_once( 'foot.php' );
?>