<?php
	include_once( 'heard.php' );
        include_once( 'heard2.php' );
	include_once( 'shujuku.php' );
?>
				
		<h2>用户登录</h2>
<?php
//如果已经登陆过了
if(isset($_SESSION['id'])){
	header("Location:list-jm.php");
	exit();
}
if(isset($_POST['id'])){
	if(strlen($_POST['id'])<2 || strlen($_POST['pwd'])<6)
	echo '<FONT COLOR="red">账户、密码错误</FONT>';
	else
	 {

		$id =$_POST['id'];
		$pwd =$_POST['pwd'];
		$user = get_user_by_id($id);
	
	//验证密码
		if($user['id'] == null)
			echo '<FONT COLOR="red">无此账号</FONT>';	
		else if(md5($pwd) == $user['pwd']){
			$_SESSION['id'] = $id;
			$_SESSION['pwd'] = $pwd;
			header("Location:list-jm.php");
			}
		else
		echo '<FONT COLOR="red">密码错误</FONT>';	

		}
}
?>
			<!--登录界面-->

	
    <div class="text-left">
        <form  action="login-jm.php" method="post">
            <div class="form-group">
                <label for="name">用户名</label>
                <input type="text" name="id" id="id" class="form-control"   placeholder="用户名"  />
            </div>
            <div class="form-group">
                <label for="name">密码</label>
                <input type="password" name="pwd" id="pwd" class="form-control" />
            </div>
            <div class="form-group">
                <a href="reg-jm.php">注册</a>
    			<button type="submit">登录</button>
            </div>
            <button type="submit" class="btn btn-success">进入</button>
        </form>
    </div>


<?php
	include_once( 'foot.php' );
?>