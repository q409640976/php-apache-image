<?php
  include_once( 'shujuku.php' );
   	$biao="blog";
		$biao_xuhao = floor(get_user_count()/14275);
		echo get_user_count();
		echo $biao_xuhao."<br>";
		if($biao_xuhao > 0)
		$biao="blog".$biao_xuhao;
		echo $biao;
?> 
