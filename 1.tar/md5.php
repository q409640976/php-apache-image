<?php
session_start();
ob_start();
header("Pragma: no-cache");
header("Cache-control: no-cache");
echo 'md5'.$_POST['username'].'<br>'.$_POST['pwd'];
//<input type="button" value="提交1" onclick="SubmitForm();">
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Android绝密日记本—云存储，高强加密</title>
	<link rel="stylesheet"  href="jm/jquery.mobile-1.0.1.min.css" />
	<link rel="stylesheet" href="jm/_assets/css/jqm-docs.css" />
	<link rel="shortcut icon" href="/images/favicon.ico" /> 
	<script src="jm/jquery.js"></script>
	<script src="jm/jquery.mobile.themeswitcher.js"></script>
	<script src="jm/_assets/js/jqm-docs.js"></script>
	<script src="jm/jquery.mobile-1.0.1.min.js"></script>
    <script type="text/javascript" src="md5.js"></script> 
    <script language="javascript"> 
    function SubmitForm() {
    	var pwd=document.getElementById('pwd');
    	if(pwd.value.length < 6 ){
 			alert("密码不能小于6位");
 			return;}
      document.getElementById("username").value = hex_md5(document.getElementById("username").value); 
    document.getElementById("pwd").value = hex_md5(document.getElementById("pwd").value); 
    document.form1.submit();
    } 
    </script> 
	</head>
<body>

	<form name="form1" action="#" method="POST">
    用户：<input id="username" name="username" value="admin"><br> 
    密码：<input id="pwd" name="pwd" type="password" value="123456"><br> 
     
    <a href="javascript:SubmitForm();" data-role="button" data-inline="true" data-theme="f">登陆</a>
    </form> 
</body>
</html>