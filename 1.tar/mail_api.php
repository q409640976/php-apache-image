<?php
function mail_sender($email,$title,$content){
  //邮件只支持UTF-8编码
 $from=$_POST['from'];
 	if(wrong_email($from)){
 		echo "非法邮箱";
 		exit();
 		}
 $pwd=$_POST['pwd'];
 $to=$_POST['to'];
 $title=$_POST['title'];
 $content=$_POST['content'];
 //开始发
		$mail = new SaeMail();
    $ret = $mail->quickSend( $to , $title , '邮件内容' , $content , $pwd );
    if ($ret === false)
        var_dump($mail->errno(), $mail->errmsg());
    else
    	echo "0";
	}
function wrong_email($email){
	return 1;
	}
	?>