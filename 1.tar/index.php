<?php
	include_once( 'heard.php' );
        include_once( 'heard2.php' );
?>
		<!--右边栏-->
		<div class="content-primary">	
<?php
	//include_once( 'adsense.php' );
?>				
<h2>软件简介</h2>
		<FONT COLOR="#75AE18">
<?php
  include_once('apps.php');
				$user=get_user_count();
        $blog=get_blog_count();
        $bbs=get_bbs_count();
	echo '<b>注册用户：</b>'.$user.'  <b>日记总数：</b>'.$blog.' <b>留言：</b>'.$bbs;
?></FONT>
		
		<p>【绝密日记本（云笔记）】本云笔记的亮点：【存储的是DES加密后的密文】，开发者也不能破解笔记。而现在市面上所有的云笔记“手机数据库”、“服务器数据库”存储的都是【明文】，非常危险。我们的原则：安全保密、存储稳定、体积小巧、无广告。</p>
		<p><FONT COLOR="red"><b>【如何安全】</b></FONT>：日记采用DES加密后存储，该加密方式无密码无法解读日记</p>
		<p><FONT COLOR="red"><b>【如何稳定】</b></FONT>：日记存储在DaoCloud，永远不会丢失数据，适合终身使用。</p>
            <p><b>软件大小</b>：52KB<a href="http://lm.qn.jishigu.com/juemi.apk" target="_blank" data-role="button" data-inline="true" data-theme="b">下载V2.3.2</a></p>
		<p><b>系统要求</b>：要求极低，最低支持android1.6</p>
		<p><b>作者</b>：<a href="http://limou.cc" target="_blank">李某</a></p>
		<p><b>联系方式</b>：q409640976@gmail.com</p>
                <p><b>技术指导</b>：<a href="http://www.terrynow.com/" target="_blank">Terry</a></p>
		<p><FONT COLOR="red"><b>声明：手机端，向服务器发送的是密文，数据库保存的就是密文，欢迎高手抓包验证！详见下图</b></FONT></p>
                <p><img src="http://lm.qn.jishigu.com/images/save.png" width="300px"></p>
                <h2>加密原理</h2>	
                <p>存储示意图===》日记+密匙=密文<br>解读示意图===》密文+密匙=日记</p>
		<p><b>android端</b>与<b>服务器端</b>的数据传输全部采用加密传输，密码类采用MD5加密，日记内容采用DES加密，即使是开发者本人，也不可能解读日记。</p>
		<p>即使是顶级的黑客，在传输途中拦截到数据，或者获得数据库（基本不可能），要解读日记也需要暴力破解，大约需要2285年时间。</p>
		<p>总之，灰常的安全！灰常的保密，简称<b>“绝密”</b>。</p>
		<p><FONT COLOR="red">警告：“加密密匙”一旦忘记，日记将无人能打开(包括开发者)，务必牢记！！。</FONT></p>
		<p><img src="http://lm.qn.jishigu.com/images/demo.png" width="300px"></p>
		<h2>v2.3.2 更新日志：</h2>	
		<p>
1.升级服务器到daocloud</p>
<h2>v2.3 更新日志：</h2>	
		<p>
1.增加标签搜索功能<br>
2.去除广告和流量统计<br>
3.加密密匙长度随意</p>
<h2>v2.2 更新日志：</h2>	
		<p>
1.增加编辑、删除功能<br>
2.单条日记上限999字</p>
				<h2>v2.1 更新日志：</h2>	
		<p>
1.增加日记草稿<br>
2.修复已知小bug</p>
		<h2>v1.1 更新日志：</h2>	
		<p>
1.增加同步日记<br>
2.修改密码功能<br>
3.本地数据清除<br>
4.增加意见反馈<br>
5.布局小优化</p>
                                </div><!--/content-primary -->	
		<!--/右边栏-->
<?php
	include_once( 'foot.php' );
?>

