<?php
include_once('shujuku.php');
//获取时间 string |float | time
function get_time($type = '') {
 	        switch ($type) {
            case 'string':   //带毫秒的字符串
            		$cdate = date('YmdHis');
            		$haomiao = microtime();
            		$haomiao1 = substr($haomiao,2,3);
            		return $cdate.$haomiao1;
                break;
            case 'float'://正规毫秒
								return microtime(TRUE);
                break;
            case 'ling'://零点时间
								return date("Y-m-d H:i:s", mktime(0,0,0));
                break;
            default:
  							return $cdate = date('Y-m-d H:i:s');
        }
 	}

function get_ip() {
	if (@$_SERVER["HTTP_X_FORWARDED_FOR"]) 
		$ip = $_SERVER["HTTP_X_FORWARDED_FOR"]; 
	else if (@$_SERVER["HTTP_CLIENT_IP"]) 
		$ip = $_SERVER["HTTP_CLIENT_IP"]; 
	else if (@$_SERVER["REMOTE_ADDR"]) 
		$ip = $_SERVER["REMOTE_ADDR"]; 
	else if (@getenv("HTTP_X_FORWARDED_FOR"))
		$ip = getenv("HTTP_X_FORWARDED_FOR"); 
	else if (@getenv("HTTP_CLIENT_IP")) 
		$ip = getenv("HTTP_CLIENT_IP"); 
	else if (@getenv("REMOTE_ADDR")) 
		$ip = getenv("REMOTE_ADDR"); 
	else 
		$ip = "0.0.0.0"; 
	return $ip; 
	}

?>