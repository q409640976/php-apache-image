<?php
	include_once( 'heard.php' );
        include_once( 'heard2.php' );
	include_once( 'shujuku.php' );
        
?>
<!--右边栏-->
		<div class="content-primary">	
<?php
	include_once( 'adsense.php' );
?>					
		<h2>修改登陆密码</h2>
<?php
//如果没登陆
if(!isset($_SESSION['id'])){
	header("Location:login-jm.php");
	exit();
}
if(isset($_POST['pwd'])){
	if(strlen($_POST['pwd1'])<6 || strlen($_POST['pwd'])<6)
	echo '<FONT COLOR="red">原登陆密码错误</FONT>';
	else
	 {
		$pwd =$_POST['pwd'];
                $pwd1 =$_POST['pwd1'];
                $pwd2 =$_POST['pwd2'];
		$user = get_user_by_id($_SESSION['id']);
	
	//验证密码
        if($pwd1!= $pwd2)
           echo '<FONT COLOR="red">新登陆密码不一致</FONT>';
        else if(strlen($pwd1)<6)
           echo '<FONT COLOR="red">新登陆密码长度错误</FONT>';
        else if($user['pwd'] !=md5($pwd))
           echo '<FONT COLOR="red">原登陆密码错误</FONT>';	
          else{
          	update_user_by_id($_SESSION['id'],"pwd",md5($pwd1));
          	echo '<FONT COLOR="red">登陆密码修改成功</FONT>';
          	}
		}
}
?>
			<!--改密码界面-->
	<form action="changepwd-jm.php" method="POST">	
		<ul data-role="listview">
		<li data-role="fieldcontain">
	        	<label for="pwd">原登陆密码:</label>
	        	<input type="password" name="pwd" id="pwd" value=""  />
			</li>
                 <li data-role="fieldcontain">
	        	<label for="pwd1">新登陆密码:</label>
	        	<input type="password" name="pwd1" id="pwd1" value=""  />
			</li>
                 <li data-role="fieldcontain">
	        	<label for="pwd2">新登陆密码:</label>
	        	<input type="password" name="pwd2" id="pwd2" value=""  />
			</li>
		<li class="ui-body ui-body-b">
<p><button type="submit" data-role="button" data-inline="true" data-theme="f">确认修改</button>
			</p>
			</li>
			
		</ul>
		
		</form>


				</div><!--/content-primary -->	
		<!--/右边栏-->
<?php
	include_once( 'foot.php' );
?>