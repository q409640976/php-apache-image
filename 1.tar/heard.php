<?php
error_reporting(E_ALL);

header("Pragma: no-cache");
header("Cache-control: no-cache");
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Android绝密日记本—云存储，高强加密</title>
        <meta name="description"
            content="Android绝密日记本，保密日记，高强加密，无懈可击，数据存在网络云服务器，永久保存" />
        <Meta name="Keywords" Content="android日记本,保密日记本,网络日记本,加密日记本,android,绝密日记本,云存储">
        <link rel="shortcut icon" href="/images/favicon.ico" /> 
        
        <link href="http://cdn.bootcss.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">
        <script src="http://upcdn.b0.upaiyun.com/libs/jquery/jquery-2.0.3.min.js"></script>
        <script src="http://cdn.bootcss.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
        
        <style>
            body {

                height: 100%;
                color: #666;
                display: table;
            }
    
            .container {
                display: table-cell;
                text-align: left;
            }
    
            .content {
                text-align: left;
                display: inline-block;
            }
        </style>