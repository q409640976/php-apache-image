<?php
class SaeMysql
{
    protected $pdo;

    function __construct()
    {
        $serverName = getenv("MYSQL_PORT_3306_TCP_ADDR");
        $databaseName = getenv("MYSQL_INSTANCE_NAME");
        $username = getenv("MYSQL_USERNAME");
        $password = getenv("MYSQL_PASSWORD");

        try {
            $this->pdo = new PDO("mysql:host=$serverName;dbname=$databaseName", $username, $password);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->pdo->query("SET NAMES utf8"); 
            //$_opts_values = array(PDO::ATTR_PERSISTENT=>true,PDO::ATTR_ERRMODE=>2,PDO::MYSQL_ATTR_INIT_COMMAND=>'SET NAMES utf8');  
            //$_pdo = new PDO(DB_DSN, DB_NAME, DB_PASS, $_opts_values); 
        } catch (PDOException $e) {
            echo "数据库链接失败: " . $e->getMessage();
            die();
        }
    }
	//sae runSql
	public function runSql( $sql )
	{
		return $this->pdo->exec($sql);
	}
	//sae getData
	public function getData( $sql )
	{
		return $this->pdo->query($sql)->fetchAll();	
	}
	//sae getData
	public function closeDb()
	{
		return true;
	}
}
