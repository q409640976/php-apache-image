
<div id="adsense2">
<script type="text/javascript"><!--
google_ad_client = "ca-pub-0224824489587078";
/* m-mini */
google_ad_slot = "3442774513";
google_ad_width = 320;
google_ad_height = 50;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
</div>