<?php
session_start();
		unset($_SESSION['id']);
		unset($_SESSION['pwd']);
		unset($_SESSION['key']);
unset($_SESSION['moshi']);//登陆模式
		header("Location:login-jm.php");
?>