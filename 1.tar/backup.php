<?php
	$date = date('Y-m-d-B');
	$dj = new SaeDeferredJob();
	$taskID = $dj->addTask("export","sql","sql","juemi-$date.sql.zip","app_juemi","","");
        echo $taskID;
?>