<?php
	include_once( 'heard.php' );
        include_once( 'heard2.php' );
?>
		<!--右边栏-->
		<div class="content-primary">	
<?php
	//include_once( 'adsense.php' );
?>				
<h2>常见问题</h2>

<h2>1.稳定吗？保密吗？</h2>	
		<p>
数据存在Daocloud服务器，稳定、可靠,且只存文本日记；<br>
日记内容密文存储，任何人都看不到（含开发者）
</p>
<h2>2.收费吗</h2>	
		<p>
永不收费，如果您觉得对您有所帮助，可以友情赞助(支付宝扫一扫)</p>
<p><img src="http://lm.qn.jishigu.com/images/weixin.jpg"></p>
<h2>3.如何同步日记到手机</h2>	
		<p>
查看日记界面==>菜单键(物理键，有的手机没有)==>下载全部</p>
<p><img src="http://lm.qn.jishigu.com/images/help.jpg"></p>


                                </div>
                                
		<!--/右边栏-->
<?php
	include_once( 'foot.php' );
?>

