<form action="1.php" method="POST">	
id<input type="text" name="id" id="" value="" style="width: 120px;" maxlength="1120" />
pwd<input type="text" name="pwd" id="" value="aaaaaaa" style="width: 120px;" maxlength="1120" />
<button type="submit">jiami</button>
</form>

<?php
$str =$_POST[id];
$key = $_POST[pwd];
$sc = new SysCrypt($key);
	 $jiami = $sc -> php_encrypt($str);
	$jiemi = $sc -> php_decrypt($str);
echo $str.'的操作<br>';
echo '加密'.$jiami."<br>";
echo '解密'.$jiemi."<br>";
/*
$str =$_POST[id];
$key = $_POST[pwd];
$crypt = new DES($key);
$mstr = $crypt->encrypt($str);
$strde = $crypt->decrypt($mstr);
echo $strde.' <=> '.$mstr;
*/
//s777n.net
class DES
{
 var $key;
 var $iv; //偏移量

 function DES( $key, $iv="j5klL96P" ) {
 //key长度8例如:1234abcd
 $this->key = $key;
 if( $iv == 0 ) {
 $this->iv = $key;
 } else {
 $this->iv = $iv; //mcrypt_create_iv ( mcrypt_get_block_size (MCRYPT_DES, MCRYPT_MODE_CBC), MCRYPT_DEV_RANDOM );
 }
 }

 function encrypt($str) {
 //加密，返回大写十六进制字符串
 $size = mcrypt_get_block_size ( MCRYPT_DES, MCRYPT_MODE_CBC );
 $str = $this->pkcs5Pad ( $str, $size );
 return strtoupper( bin2hex( mcrypt_cbc(MCRYPT_DES, $this->key, $str, MCRYPT_ENCRYPT, $this->iv ) ) );
 }

 function decrypt($str) {
 //解密
 $strBin = $this->hex2bin( strtolower( $str ) );
 $str = mcrypt_cbc( MCRYPT_DES, $this->key, $strBin, MCRYPT_DECRYPT, $this->iv );
 $str = $this->pkcs5Unpad( $str );
 return $str;
 }

 function hex2bin($hexData) {
 $binData = "";
 for($i = 0; $i < strlen ( $hexData ); $i += 2) {
 $binData .= chr ( hexdec ( substr ( $hexData, $i, 2 ) ) );
 }
 return $binData;
 }

 function pkcs5Pad($text, $blocksize) {
 $pad = $blocksize - (strlen ( $text ) % $blocksize);
 return $text . str_repeat ( chr ( $pad ), $pad );
 }

 function pkcs5Unpad($text) {
 $pad = ord ( $text {strlen ( $text ) - 1} );
 if ($pad > strlen ( $text ))
 return false;
 if (strspn ( $text, chr ( $pad ), strlen ( $text ) - $pad ) != $pad)
 return false;
 return substr ( $text, 0, - 1 * $pad );
 }

}


class SysCrypt {

private $crypt_key;

// 构造函数
public function __construct($crypt_key) {
   $this -> crypt_key = $crypt_key;
}

public function php_encrypt($txt) {
   srand((double)microtime() * 1000000);
   $encrypt_key = md5(rand(0,32000));
   $ctr = 0;
   $tmp = '';
   for($i = 0;$i<strlen($txt);$i++) {
    $ctr = $ctr == strlen($encrypt_key) ? 0 : $ctr;
    $tmp .= $encrypt_key[$ctr].($txt[$i]^$encrypt_key[$ctr++]);
   }
   return base64_encode(self::__key($tmp,$this -> crypt_key));
}

public function php_decrypt($txt) {
   $txt = self::__key(base64_decode($txt),$this -> crypt_key);
   $tmp = '';
   for($i = 0;$i < strlen($txt); $i++) {
    $md5 = $txt[$i];
    $tmp .= $txt[++$i] ^ $md5;
   }
   return $tmp;
}

private function __key($txt,$encrypt_key) {
   $encrypt_key = md5($encrypt_key);
   $ctr = 0;
   $tmp = '';
   for($i = 0; $i < strlen($txt); $i++) {
    $ctr = $ctr == strlen($encrypt_key) ? 0 : $ctr;
    $tmp .= $txt[$i] ^ $encrypt_key[$ctr++];
   }
   return $tmp;
}

public function __destruct() {
   $this -> crypt_key = null;
}
}
/*
$sc = new SysCrypt($key);
 $str = $sc -> php_encrypt($str);
print('<br>');
print($sc -> php_decrypt($sc -> php_encrypt($text)));
*/
?>