<?php
	include_once( 'heard.php' );
  include_once( 'heard2.php' );
  include_once( 'shujuku.php' );
?>
<h2>留言反馈</h2>
<?php
if (empty($_SESSION['id']))
{
  echo '<p><a href="login-jm.php" data-role="button" data-inline="true" data-theme="b">请登录后发言</a></p>';
	}
if(!empty($_POST['neirong']) && !empty($_SESSION['id']))
{
//开始添加
	$guest = $_POST;
	$guest[udate] = get_time();
  $guest[uid] = $_SESSION['id'];
  $guest[name] = $_SESSION['id'];
//var_dump($schedule);
if(strlen($_POST['neirong']) > 300)
echo '留言失败，字数超过100';
else{
add_bbs($guest);
echo '留言成功';

echo '<meta http-equiv="refresh" content="1; url=bbs-jm.php">';
}
	}		
$page = 1;
if(isset($_GET['page']))
	$page = $_GET['page'];
//显示列表
	$lists = get_bbs(1,10000);
	$zongshu = sizeof($lists);
	$list = get_bbs($page,10);

	echo "<p>留言总数: $zongshu 第 $page 页</p>";
if(sizeof($list)){
	echo '<ul data-role="listview">';
	foreach ($list as $v){
		$username = $v['name'];
		if ($username =='liming')
			$username='管理员';
echo '<li>
				<h3>【'.$username.'】说：</h3>
				<p class="ui-li-desc1">'.$v['neirong'].'</p>
				<p class="ui-li-aside"><strong>'.$v['udate'].'</strong>PM</p>
			</li>	';
			}
			echo '</ul>';
	}
$page1 = $page-1;
$page2 = $page+1;
$shangyige = "";
$xiayige = "";
if($page1>0)
$shangyige = '<a href="/bbs-jm.php?page='.$page1.'"><button data-role="button" data-inline="true" data-theme="d">上一页 </button></a>';
$shengyu = $zongshu - $page*10;
if($shengyu>0)
$xiayiye = '<a href="/bbs-jm.php?page='.$page2.'"><button data-role="button" data-inline="true" data-theme="d">下一页 </button></a>';
echo '</tbody></table><p>'.$shangyige.'  '.$xiayiye.'<br>';
if (!empty($_SESSION['id'])){//没登陆不显示留言框
	echo '<form action="bbs-jm.php" method="POST">	
				<div data-role="fieldcontain">
<p><label for="search">输入留言:</label></p>
    			<textarea name= "neirong" rows= "3 "></textarea>
				</div>
				<p><button type="submit" data-role="button" data-inline="true" data-theme="b">提交留言</button>
</p></form>';
}
?>


		<!--/右边栏-->
<?php
	include_once( 'foot.php' );
?>