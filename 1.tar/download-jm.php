<?php
	include_once( 'heard.php' );
        include_once( 'heard2.php' );
?>
				
		<h2>软件下载-2.3.2版</h2>
                <p><b>软件大小</b>：52KB</p>
		<p><b>系统要求</b>：要求极低，最低支持android1.6</p>
		<p><a href="juemi.apk" target="_blank" data-role="button" data-inline="true" data-theme="b">下载2.3.2版</a></p>		
		<p><img src="http://lm.qn.jishigu.com/images/demo.png"></p>

				</div><!--/content-primary -->	
		<!--/右边栏-->

<?php
	include_once( 'foot.php' );
?>