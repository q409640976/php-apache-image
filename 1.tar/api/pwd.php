<?php
include_once('../shujuku.php');
//传入数据
$id = $_POST['id'];//用户id
$oldpwd = $_POST['oldpwd'];//原pwd的md5码
$newpwd = $_POST['newpwd'];//新pwd的md5码

//验证密码
$user = get_user_by_id($id);
if($user['pwd'] != $oldpwd){
	echo "原始密码错误,false";
	exit();
	}
if(strlen($newpwd) < 2)
echo '新密码非法,false';
else{
update_user_by_id($id,"pwd",$newpwd);
echo '密码修改成功,true';
}
?>