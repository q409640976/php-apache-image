<?php
include_once('../shujuku.php');
//传入数据
$id = $_POST['id'];//用户id
echo get_user_blog_count($id);
?>