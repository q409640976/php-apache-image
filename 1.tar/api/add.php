<?php
error_reporting(E_ALL);
include_once('../shujuku.php');
include_once('../des.class.php');
//传入数据
$id = $_POST['id'];//用户id
$jiemi = $_POST['jiemi'];//解密的md5码
$sid = $_POST['sid'];//日记的sid
$lei = 1;//日记默认分类
$content = $_POST['content'];//日记内容（des加密后的）
$ver = 1;//当前版本
if(isset($_POST['ver']))
	$ver = $_POST['ver'];
if(isset($_POST['$lei']))
	$lei = $_POST['$lei'];

if(strlen($id)<2){
	echo "登陆超时，请重新登录,false";
	exit();
}
//验证用户密码
$user = get_user_by_id($id);
if($user['jiemi'] != $jiemi){
	echo "发送失败，加密密匙错误,false";
	exit();
	}
//判断是否为删除
if($content == "delete"){
	if(delete_blog($_POST)){
  	echo "删除成功,deleted";
  	update_user_by_id($id,"udate",get_time(""));
  	}
	else
		echo "删除失败,false";
	exit();
}
if(strlen($content)<1 || strlen($content)>20000){
	echo "内容太长，建议分批,false";
	exit();
}
if(strlen($sid)<1){
	echo "程序bug错误码：add-37,false";
	exit();
}
//今后版本提示格式 【toast内容,true,更新内容,"newver"】
if(add_blog_by_id($_POST)){
	$rts = "成功！,true,";//近期停止服务，请注意备份.
	if($ver <2.3 )
	$rts = "云存储成功
发现新版本2.3,true,
版本2.3\n【标签搜索、精简代码】,newver";
  echo $rts;
  update_user_by_id($id,"udate",get_time(""));
  update_user_by_id($id,"ver",$ver);
  }
else
	echo "失败，云服务器错误,false";
?>