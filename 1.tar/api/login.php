<?php
include_once('../shujuku.php');
//应传入的数据
$id = $_POST['id'];
$pwd = $_POST['pwd'];
$jiemi = $_POST['jiemi'];

if(strlen($id)<2){
	echo "账户长度不对,false";
	exit();
}
if(strlen($pwd)!=32){
	echo "密码长度不对,false";
		exit();
	}
if(strlen($jiemi)!=32){
	echo "加密密匙长度不对,false";
		exit();
	}
$user = get_user_by_id($id);
if($user == null){
	echo "无此账号,false";
	exit();
	}
if($user['pwd'] == $pwd){
	if($user['jiemi'] == $jiemi)
	echo $user['sid'].",true";
	else echo "加密密匙错误，如遗忘请放弃此号";
}
else echo "密码错误,false";

?>