<?php
	echo "停止注册,false";
	exit();
include_once('../shujuku.php');
$id = $_POST['id'];
$pwd = $_POST['pwd'];
$jiemi = $_POST['jiemi'];


if (strlen($id)<6){
	echo "账户长度不够,false";
	exit();
}
$pwd =$_POST['pwd'];
if(strlen($pwd)!=32){
	echo "登陆密码长度不够,false";
		exit();
	}
if(strlen($jiemi)!=32){
	echo "加密密匙长度必须为8位,false";
		exit();
	}
$user = get_user_by_id($id);
if($user == null){
	$newuser= $_POST;
	$newuser['ip']='m:'.get_ip();
	add_user($newuser);
  $user0 = get_user_by_id($id);
	echo $user0['sid'].",true";
	exit();
	}
else
  echo "用户已存在,false";



?>
