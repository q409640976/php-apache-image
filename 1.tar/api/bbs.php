<?php
include_once('../shujuku.php');
//传入数据
$id = $_POST['id'];//用户id
$pwd = $_POST['pwd'];//pwd的md5码
$content = $_POST['content'];//日记内容（des加密后的）
if(strlen($id)<2 || strlen($pwd)<2){
	echo "非法请求,false";
	exit();
	}
//验证密码
$user = get_user_by_id($id);
if($user['pwd'] != $pwd){
	echo "留言失败，非法登录错误,false";
	exit();
	}
//开始添加
	$guest = $_POST;
	$guest['udate'] = get_time();
  $guest['uid'] = $id;
  $guest['name'] = $id;
  $guest['neirong'] = $content;
if(strlen($content) > 300)
echo '留言失败，字数超过100,false';
else{
add_bbs($guest);
echo '留言成功，站长会及时处理,true';
}
?>