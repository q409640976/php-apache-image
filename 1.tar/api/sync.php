<?php
include_once('../shujuku.php');
//传入数据
$id = $_POST['id'];//用户id
$pwd = $_POST['pwd'];//pwd的md5码
$page = $_POST['page'];
$max = $_POST['max'];//需要同步的上限
if(strlen($id)<2 || strlen($pwd)<2){
	echo "非法请求,false";
	exit();
	}
//验证密码
$user = get_user_by_id($id);
if($user['pwd'] != $pwd){
	echo "非法登录,false";
	exit();
	}
else{
$arr = get_blogs($id,$page,$max);
//get_blogs($id,$ye = 1,$max = 20,$lei=0)
echo json_encode($arr);
}

?>