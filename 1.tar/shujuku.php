<?php
include_once('apps.php');
include_once('SaeMysql.php');
//获取数据库信息
function get_info(){
		$user=get_user_count();
        $blog=get_blog_count();
        $bbs=get_bbs_count();
        $newuser=get_new_user();
        $newblog=get_today_blog();
        $huoyue = get_today_user();
	return '今天活跃用户：'.$huoyue."(".$newuser.")/".$user.' 日记：('.$newblog.")".$blog.' 留言：'.$bbs;
     }
//获取用户总数
function get_user_count(){
	$mysql = new SaeMysql();	
						$sql = "select count(*) from user";
						$data = $mysql->getData( $sql );
						$mysql->closeDb();
						return $data[0]["count(*)"];
	}
//获取当天new blog
function get_today_blog(){
	$mysql = new SaeMysql();	
	$cdate= get_time("ling");
						$sql = "select count(*) from blog where cdate>'$cdate'";
						$sql1 = "select count(*) from blog1 where cdate>'$cdate'";
						$sql2 = "select count(*) from blog2 where cdate>'$cdate'";
						$data = $mysql->getData( $sql );
						$data1 = $mysql->getData( $sql1 );
						$data2 = $mysql->getData( $sql2 );
						$mysql->closeDb();
						return $data[0]["count(*)"]+$data1[0]["count(*)"]+$data2[0]["count(*)"];
	}
//获取当天活跃用户
function get_today_user(){
	$mysql = new SaeMysql();	
	$udate= get_time("ling");
						$sql = "select count(*) from user where udate>'$udate'";
						$data = $mysql->getData( $sql );
						$mysql->closeDb();
						return $data[0]["count(*)"];
	}
//获取当天new用户
function get_new_user(){
	$mysql = new SaeMysql();	
	$cdate= get_time("ling");
						$sql = "select count(*) from user where cdate>'$cdate'";
						$data = $mysql->getData( $sql );
						$mysql->closeDb();
						return $data[0]["count(*)"];
	}
//获取blog总数
function get_blog_count(){
	$mysql = new SaeMysql();	
						$sql = "select count(*) from blog";
						$sql1 = "select count(*) from blog1";
						$sql2 = "select count(*) from blog2";
						$data = $mysql->getData( $sql );
						$data1 = $mysql->getData( $sql1 );
						$data2 = $mysql->getData( $sql2 );
						$mysql->closeDb();
						return $data[0]["count(*)"]+$data1[0]["count(*)"]+$data2[0]["count(*)"];
	}
//获取留言总数
function get_bbs_count(){
	$mysql = new SaeMysql();	
						$sql = "select count(*) from bbs";
						$data = $mysql->getData( $sql );
						$mysql->closeDb();
						return $data[0]["count(*)"];
	}
//根据ID，获取用户数据所存的表
function get_user_biao($id){
	$mysql = new SaeMysql();	
	$sql = "select biao from user where id='$id'";
						$data = $mysql->getData( $sql );
						$mysql->closeDb();
						return $data[0]["biao"];
	}
//获取指定用户blog数量【需要更改blog表】
function get_user_blog_count($id){
	$mysql = new SaeMysql();	
	$cdate= get_time("ling");
						$sql = "select count(*) from ".get_user_biao($id)." where user='$id'";
						$data = $mysql->getData( $sql );
						$mysql->closeDb();
						return $data[0]["count(*)"];
	}
//获取用户指定sid日记的数量（判断是否为升级）
function get_this_blog_count($userid,$sid){
	$mysql = new SaeMysql();	
	$cdate= get_time("ling");
						$sql = "select count(*) from ".get_user_biao($userid)." where user='$userid' and id='$sid'";
						$data = $mysql->getData( $sql );
						$mysql->closeDb();
						return $data[0]["count(*)"];
	}
//添加user返回sid
function add_user($user){
		$cdate= get_time("");
		$mysql = new SaeMysql();
		$sid= get_time("string");
		//判断新用户日记应该存在哪个表
		$biao="blog";
		$biao_xuhao = floor(get_user_count()/14276);//ceil
		if($biao_xuhao > 0)
		$biao="blog".$biao_xuhao;
    $sql = "INSERT INTO user (id,pwd,jiemi,cdate,udate,sid,ip,biao) VALUES ('$user[id]','$user[pwd]','$user[jiemi]','$cdate','$cdate','$sid','$user[ip]','$biao')";
    $mysql->runSql( $sql );
    $mysql->closeDb();
    return $sid;
	}
//添加blog by sid(SID，内容，类型,time)
function add_blog_by_id($POST){
		$cdate=get_time("");
			$userid = $POST['id'];//用户id
			$sid = $POST['sid'];//日记的sid
			$lei = $POST['lei'];//日记分类
			$content = $POST['content'];//日记内容（des加密后的）  	
		  $mysql = new SaeMysql();
			//判断是否为升级
		if(get_this_blog_count($userid,$sid)>0)
				{
					$sql = "update ".get_user_biao($userid)." set content='$content' ,lei='$lei' where user='$userid' and id='$sid'";
					if($mysql->runSql( $sql ))
    				{
    					$mysql->closeDb();
      				return 1;
      			}
     			else
          	{
              $mysql->closeDb();
      				return 0;
             }
					}
		else{
    	$sql = "INSERT INTO ".get_user_biao($userid)." (id,user,cdate,content,lei) VALUES ('$sid','$userid','$cdate','$content','$lei')";
      if($mysql->runSql( $sql ))
    		{
    			$mysql->closeDb();
      		return 1;
      	}
      else
          	{
                $mysql->closeDb();
      		return 0;
             }
        }
    
	}
//删除
function delete_blog($POST){
			$cdate=get_time("");
			$userid = $POST['id'];//用户id
			$sid = $POST['sid'];//日记的sid 	
		  $mysql = new SaeMysql();
			//判断是否有此blog
		if(get_this_blog_count($userid,$sid)>0)
				{
					$sql = "delete from ".get_user_biao($userid)." where user='$userid' and id='$sid'";
					if($mysql->runSql( $sql ))
    				{
    					$mysql->closeDb();
      				return 1;
      			}
     			else
          	{
              $mysql->closeDb();
      				return 0;
             }
					}
		else 
			return 0;

    
	}
//根据SID获取用户
function get_user_by_sid($sid){
	$mysql = new SaeMysql();	
						$sql = "SELECT * FROM `user` where sid='$sid'";
						$data = $mysql->getData( $sql );
						$mysql->closeDb();
						return $data[0];
	}
//根据ID获取用户
function get_user_by_id($id){
	$mysql = new SaeMysql();	
						$sql = "SELECT * FROM `user` where id='$id'";
						$data = $mysql->getData( $sql );
						$mysql->closeDb();
						return $data[0];
	}
//更新user格式：[id,列名，值]
function update_user_by_id($id,$col,$v){
		$mysql = new SaeMysql();
		$sql = "update user set $col='$v' where id='$id'";
		//echo $sql;
		$mysql->runSql( $sql );
		$mysql->closeDb();
	}
//更新user格式：[sid,列名，值]
function update_user_by_sid($id,$col,$v){
		$mysql = new SaeMysql();
		$sql = "update user set $col='$v' where sid='$sid'";
		$mysql->runSql( $sql );
		$mysql->closeDb();
	}
//获取ID下的列表 id page max lei
function get_blogs($id,$ye = 1,$max = 20,$lei=""){
	$start = ($ye-1)*$max;
	$mysql = new SaeMysql();	
	$sql = "SELECT * FROM `".get_user_biao($id)."` where user='$id' and lei like '%$lei%' ORDER BY id DESC limit $start,$max";
	$data = $mysql->getData( $sql );
						$mysql->closeDb();
						//echo 'cccccccccccccccc'.$sql;
						return $data;
	}
//添加留言
function add_bbs($bbs){
		$mysql = new SaeMysql();
    $sql = "INSERT INTO bbs (uid,name,neirong,udate) VALUES ('$bbs[uid]','$bbs[name]','$bbs[neirong]','$bbs[udate]')";
    $mysql->runSql( $sql );
    $mysql->closeDb();
	}
//获取留言
function get_bbs($ye = 1,$vol = 20){
	$start = ($ye-1)*$vol;
	$mysql = new SaeMysql();	
						$sql = "SELECT * FROM `bbs` order by udate desc limit $start,$vol";
						$data = $mysql->getData( $sql );
						$mysql->closeDb();
						return $data;
	}
?>