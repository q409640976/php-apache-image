<?php
	include_once( 'heard.php' );
        include_once( 'heard2.php' );
	include_once( 'shujuku.php' );
?>
		<!--右边栏-->
		<div class="content-primary">	
<?php
	include_once( 'adsense.php' );
?>					
		<h2>用户注册</h2>
                  <p>用户名6位以上;密码6位以上</p>
<?php
//如果已经登陆过了
if(isset($_SESSION['id'])){
	header("Location:list-jm.php");
	exit();
}
if(isset($_POST['id'])){
	if(strlen($_POST['id'])>0)
	echo '<FONT COLOR="red">暂停网页注册,联系站长QQ:409640976</FONT>';
	else if(strlen($_POST['pwd'])<6)
	echo '<FONT COLOR="red">密码最少为6位</FONT>';
	else if($_POST['pwd'] != $_POST['pwd1'])
	echo '<FONT COLOR="red">登陆密码输入不一致</FONT>';
	else if(strlen($_POST['key'])<6)
	echo '<FONT COLOR="red">加密密匙，至少6位</FONT>';
	else if($_POST['key'] != $_POST['key1'])
	echo '<FONT COLOR="red">加密密匙不一致</FONT>';
	else
	 {

		$id =$_POST['id'];
		$pwd =$_POST['pwd'];
		$_POST['pwd']=md5($_POST['pwd']);
                $_POST['jiemi']=md5($_POST['key']);
		$user = get_user_by_id($id);

	//验证密码
		if($user['id'] != null)
			echo '<FONT COLOR="red">该账户已经被使用</FONT>';	
		else {
			$newuser= $_POST;
			$newuser['ip']=$ip;
			add_user($newuser);
			header("Location:login-jm.php");
			}	
		}
}
?>
			<!--注册界面-->
	<form action="reg-jm.php" method="POST">
		<ul data-role="listview">
			<li data-role="fieldcontain">
	        	<label for="name">用户名称:</label>
	        	<input type="text" name="id" id="id" value=""  />
			</li>
			<li data-role="fieldcontain">
	        	<label for="name">登录密码:</label>
	        	<input type="password" name="pwd" id="pwd" value=""  />
			</li>
			<li data-role="fieldcontain">
	        	<label for="name">登录密码:</label>
	        	<input type="password" name="pwd1" id="pwd1" value=""  />
			</li>
			<li data-role="fieldcontain">
	        	<label for="name">加密密匙:</label>
	        	<input type="password" name="key" id="key" value=""  />
			</li>
			<li data-role="fieldcontain">
	        	<label for="name">加密密匙:</label>
	        	<input type="password" name="key1" id="key1" value=""  />
			</li>

			<li class="ui-body ui-body-b">
<p><a href="login-jm.php" data-role="button" data-inline="true" data-theme="b">已经有账号</a>
					<button type="submit" data-role="button" data-inline="true" data-theme="f">注册</button>
			</p>



			</li>
			
		</ul>
		
		</form>
<p><h4>
    <FONT COLOR="red">警告：“加密密匙”一旦忘记，日记将无人能打开(包括开发者)，务必牢记！！。</FONT>
</h4></p>
				</div><!--/content-primary -->	
		<!--/右边栏-->
<?php
	include_once( 'foot.php' );
?>