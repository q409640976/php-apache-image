<?php
	echo "停止注册..,false";
		exit();
include_once('shujuku.php');
if(isset($_POST['id'])){
$id = $_POST['id'];
$ip = get_ip();

$pwd =$_POST['pwd'];
if(strlen($pwd)<6){
	echo "登陆密码长度不够,false";
		exit();
	}
if(strlen($_POST['jiemi'])<6){
	echo "加密密匙长度不够,false";
		exit();
	}
$user = get_user_by_id($id);
if($user == null){
	$newuser= $_POST;
	$newuser['ip']=$ip;
	add_user($newuser);
  $user0 = get_user_by_id($id);
	echo "$user0[sid],true";
	exit();
	}
else
  echo "用户已存在,false";}
//  <form action="reg.php" method="POST">	
// <input type="text" name="id" id="id" value="" style="width: 120px;" maxlength="20" />
// <input type="text" name="pwd" id="pwd" value="" style="width: 120px;" maxlength="20" />
// <input type="text" name="jiemi" id="jiemi" value="" style="width: 120px;" maxlength="20" />
//				<p><button type="submit">注册</button>
//</p>
//</form>

?>
