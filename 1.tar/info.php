<!DOCTYPE html>
<html>
	<head>
	<meta charset="utf-8">
</head> 
<a href="bbs-jm.php">
<?php
  include_once('apps.php');
  echo get_info();
?></a>
</html>