
</head> 
<body> 
<!--内容-->
<div data-role="content">
    <nav class="navbar navbar-default" role="navigation">
       <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse"  data-target="#example-navbar-collapse">
             <span class="sr-only">切换导航</span>
             <span class="icon-bar"></span>
             <span class="icon-bar"></span>
             <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="/">绝密日记本</a>
       </div>
       <div class="collapse navbar-collapse" id="example-navbar-collapse">
          <ul class="nav navbar-nav">
            <li<?php
    		if ( $_SERVER['PHP_SELF']=='/index.php')
    		    echo ' class="active"';
    		?>><a href="/">首页</a></li>
    		<li<?php
    		if ( $_SERVER['PHP_SELF']=='/list-jm.php')
    		    echo ' class="active"';
    		?>><a href="list-jm.php">浏览日记</a></li>
    		<li<?php
    		if ( $_SERVER['PHP_SELF']=='/download-jm.php')
    		    echo ' class="active"';
    		?>><a href="download-jm.php">软件下载</a></li>
    		<li<?php
    		if ( $_SERVER['PHP_SELF']=='/bbs-jm.php')
    		    echo ' class="active"';
    		?>><a href="bbs-jm.php">留言反馈</a></li>
    		<li<?php
    		if ( $_SERVER['PHP_SELF'] == '/help-jm.php')
    		    echo ' class="active"';
    		?>><a href="help-jm.php">常见问题</a></li>

    		<?php
    		    $act="";
    		    if ( $_SERVER['PHP_SELF'] == '/login-jm.php')
    		    $act =  ' class="active"';
    			if (empty($_SESSION['id']))
    				echo '<li'.$act.'><a href="login-jm.php">登录</a></li>';
    			else{
    				echo '<li><a href="loginout-jm.php">退出</a></li>';
    				echo '<li><a href="changepwd-jm.php">修改密码</a></li>';
    				}
    		?>
          </ul>
       </div>
    </nav>
	<!--/左边导航-->
	<!--内容-->
    <div class="container bs-docs-container">
	